//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FORTH.RC
//
#define ICON_FORTH                      100
#define APP_ICON                        101
#define IDC_SPLITV                      114
#define IDC_SPLITH                      115
#define IDC_MAGNIFY                     116
// #define IDC_HAND                        119
#define IDC_HARROW                      120

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        121
#define _APS_NEXT_COMMAND_VALUE         101
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
