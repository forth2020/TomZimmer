SinarF4 2014 Dec 21

Added    s" \\.\COM" to make higher COM ports work
Built with Win32Forth V6.01 to avoid AntiVirus warnings.
Has Reset Remote Unit's time function.
Faster download and upload

